<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2 style="border: 1px sold;">hello page</h2>
    <h3>@yield('title','hello thon')</h3>
@section('content')
<h2>@yield('title','the school')</h2>
<h1>hello thon</h1>
@endsection



</body>
</html>
