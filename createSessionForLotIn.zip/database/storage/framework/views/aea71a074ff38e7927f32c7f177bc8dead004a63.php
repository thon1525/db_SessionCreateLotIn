<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="<?php echo e(route('submit')); ?>">
        <?php echo csrf_field(); ?>
        <label for="fname">First name:</label><br>
        <input type="text" id="fname" name="name"><br>
        <label for="lname">Last name:</label><br>
        <input type="password" id="lname" name="pass"><br><br>
        <input type="submit" value="Submit">
      </form>
</body>
</html>
<?php /**PATH D:\Laravel\makesession\makesession\DbAPI\database\resources\views/makeaccout.blade.php ENDPATH**/ ?>