<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\produst;
use Illuminate\Http\Request;

class DatabaseController extends Controller
{
    // create session for lot in
    public function makesession(Request $request){
        $logname= $request->input('name');
        $logpass= $request->input('pass');

        $result = DB::table('tbluser')->where('username', $logname)
        ->where('password', $logpass)
        ->first();
        if(isset($result))
        {
            $userid = $result->userid;
            $username = $result->username;
            // create session
            // $_SESSION["userid"]= $userid
            // $_SESSION["username"]=$username;
               // create session
            session(['userid' => $userid,'username'=>$username]);
            echo 1;
        }else{
            echo 0;
        }


        //  $makesessionid= session('key', );
        //   $makesessionname= session('key',  );
      /*    $datasession = [
                 'username'=> $makesessionname,
                 'userid'=>  $makesessionid
          ];
        */
       //   echo $makesessionid;
        }

        // create for model
        public function makemodel(){
            $table=produst::get();
            foreach($table as $objname){
            echo    $objname->email;
              echo  $objname->token;
            echo    $objname->created_at;
            echo "<br>";
            }
        }

            // create for model 
    }

