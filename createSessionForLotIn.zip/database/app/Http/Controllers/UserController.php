<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function controlleruser(){

        // return view("user");
        $resurt= DB::table("tbluser")->paginate(5);
        
        // foreach ($resurt as $obj){
        //    echo $obj->userid;
        //    echo $obj->username;
        //    echo $obj->status;
        //    echo "<br>";
        // }
        


     return view('user',['userdata'=>$resurt]);
        
    }

    
    public function showdata(Request $rq){
       $username=$rq->txtuser;
       $userpassword=$rq->txtpass;
       $userslstarte=$rq->slstatus;
       DB::table('tbluser')->insert([
      'username'=>$username,
      'password'=>$userpassword,
      'status'=>$userslstarte,
       ]);
       echo "Data has been ";
    }
}
